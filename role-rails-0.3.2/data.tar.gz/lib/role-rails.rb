require 'rails'
require 'role-rails/version'

module Role
  module Rails
    require 'role-rails/engine'
  end
end
