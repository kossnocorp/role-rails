require 'rails'

module Role
  module Rails
    class Engine < ::Rails::Engine
    end
  end
end
