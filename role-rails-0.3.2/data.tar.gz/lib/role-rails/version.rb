module Role
  module Rails
    VERSION = '0.3.2'
  end
end
